# SPDX-License-Identifier: GPL-3.0-or-later
"""Settings stored in the .blend file."""

import bpy
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty,
                       PointerProperty, StringProperty)

from . import mapsview as V
from . import presets as P


class BPM_SlotBackup(bpy.types.PropertyGroup):
    """Original material of a slot, kept while the baked material is shown."""
    index: IntProperty()
    material: PointerProperty(type=bpy.types.Material)


class BPM_ViewSlot(bpy.types.PropertyGroup):
    """A material slot as it was before the analysis view was shown on it."""
    index: IntProperty()
    link: StringProperty(default='DATA')
    material: PointerProperty(type=bpy.types.Material)


def _analysis_view_changed(self, context):
    V.update(context)


RESOLUTIONS = [
    ('512', '512', '512 x 512 pixels: fast, for small or distant objects'),
    ('1024', '1K', '1024 x 1024 pixels'),
    ('2048', '2K', '2048 x 2048 pixels: good default'),
    ('4096', '4K', '4096 x 4096 pixels: high detail, slower'),
    ('8192', '8K', '8192 x 8192 pixels: very slow and uses a lot of memory'),
]


class BPM_Settings(bpy.types.PropertyGroup):
    # --- library
    category: EnumProperty(
        name='Category',
        items=[('ALL', 'All', 'Show every material', 0)] + [(c[0], c[3], c[2], c[4]) for c in P.CATEGORIES],
        default='ALL')
    fit_to_object: BoolProperty(
        name='Fit Pattern Size to Object', default=True,
        description='Adapt the pattern size (scratches, grain, dirt...) to the size of the selected object(s)')
    show_all_settings: BoolProperty(
        name='Show All Settings', default=False,
        description='Show every setting of the material, not just the most important ones')

    # --- bake
    bake_mode: EnumProperty(
        name='Bake Mode',
        items=[('OBJECTS', 'Objects',
                'Bake textures that fit the UV map of each selected object (for game engines / export)', 'OBJECT_DATA', 0),
               ('TILE', 'Seamless Tile',
                'Bake square textures that repeat seamlessly (for texture libraries or other software)', 'TEXTURE', 1)],
        default='OBJECTS')
    bake_scope: EnumProperty(
        name='Objects',
        items=[('ACTIVE', 'Active', 'Only the active object (the one you clicked last)', 'OBJECT_DATA', 0),
               ('SELECTED', 'Selected', 'All selected objects', 'RESTRICT_SELECT_OFF', 1),
               ('SCENE', 'Scene', 'Every visible mesh object in the scene', 'SCENE_DATA', 2)],
        default='SELECTED',
        description='Which objects to texture')
    resolution: EnumProperty(name='Resolution', items=RESOLUTIONS, default='2048',
                             description='Size of the baked textures in pixels')
    quality: EnumProperty(
        name='Quality',
        items=[('FAST', 'Fast', 'Quick preview bake (slightly grainy)'),
               ('GOOD', 'Good', 'Clean result, recommended'),
               ('BEST', 'Best', 'Smoothest result, slowest')],
        default='GOOD')
    map_base_color: BoolProperty(name='Base Color', default=True, description='Color texture (sRGB)')
    map_metallic: BoolProperty(name='Metallic', default=True, description='Black = paint/rust, white = metal')
    map_roughness: BoolProperty(name='Roughness', default=True, description='Black = glossy, white = matte')
    map_transmission: BoolProperty(
        name='Transmission', default=True,
        description='Glass only: white = see-through, black = opaque (also saved inverted as an Opacity '
                    'map for game engines). Skipped for materials that let no light through')
    map_emission: BoolProperty(
        name='Emission', default=True,
        description='Glowing parts (lava): the glow color. Skipped for materials that do not glow')
    map_normal: BoolProperty(name='Normal', default=True, description='Surface detail (normal map)')
    map_height: BoolProperty(name='Height', default=True, description='Height / displacement map (16-bit)')
    map_ao: BoolProperty(name='Ambient Occlusion', default=True,
                         description='Ambient occlusion: soft shadows in crevices (Objects mode only)')
    normal_format: EnumProperty(
        name='Normal Map Format',
        items=[('OPENGL', 'OpenGL', 'Blender, Unity, Godot, glTF, Substance (default)'),
               ('DIRECTX', 'DirectX', 'Unreal Engine, CryEngine, 3ds Max')],
        default='OPENGL')
    bit_depth: EnumProperty(
        name='Bit Depth',
        items=[('8', '8-bit', 'Normal PNG files (smaller)'),
               ('16', '16-bit', 'Higher precision PNG files (bigger)')],
        default='8')
    pack_orm: BoolProperty(
        name='Packed ORM', default=False,
        description='Also save one texture with AO (red), Roughness (green), Metallic (blue): '
                    'Unreal Engine and glTF use this')
    pack_unity: BoolProperty(
        name='Unity Metallic/Smoothness', default=False,
        description='Also save Unity\'s Metallic (RGB) + Smoothness (alpha) texture')
    output_dir: StringProperty(
        name='Folder', subtype='DIR_PATH', default='//BPM_Textures/',
        description='Where the textures are saved ("//" means next to your .blend file). '
                    'If the .blend file was never saved, a BPM_Textures folder in your home folder is used')
    assign_baked: BoolProperty(
        name='Use Baked Material', default=True,
        description='Switch the object to a material that uses the baked textures (Auto Texture always '
                    'does). The procedural material is kept and can be restored any time')
    auto_unwrap: BoolProperty(
        name='Auto UV Unwrap', default=True,
        description='"Bake with Current UVs": make new UVs for objects that have none (or broken / '
                    'overlapping ones)')
    device: EnumProperty(
        name='Device',
        items=[('AUTO', 'Auto', 'Use the GPU if one is set up in Preferences > System, otherwise the CPU'),
               ('CPU', 'CPU', 'Always bake on the CPU'),
               ('GPU', 'GPU', 'Bake on the GPU (falls back to CPU if none is set up)')],
        default='AUTO')
    tile_size: FloatProperty(
        name='Tile Size', default=1.0, min=0.01, soft_max=10.0, subtype='DISTANCE', unit='LENGTH',
        description='How much real-world surface one seamless tile shows')

    # --- mesh maps
    maps_resolution: EnumProperty(
        name='Map Size', items=RESOLUTIONS[:4], default='1024',
        description='Size of each object\'s mesh maps in pixels (1K is plenty for most objects)')
    maps_quality: EnumProperty(
        name='Quality',
        items=[('FAST', 'Fast', 'Quick analysis (slightly rough bands)'),
               ('GOOD', 'Good', 'Clean result, recommended'),
               ('BEST', 'Best', 'Smoothest result, slowest')],
        default='GOOD')
    maps_edge_reach: FloatProperty(
        name='Edge Reach', default=5.0, min=0.5, max=25.0, subtype='PERCENTAGE', precision=1,
        description='How far from an outer edge the analysis looks, as a share of the object\'s size. '
                    'Edge wear can be at most about half as wide')
    maps_cavity_reach: FloatProperty(
        name='Corner Reach', default=15.0, min=0.5, max=25.0, subtype='PERCENTAGE', precision=1,
        description='How far out of inner corners and creases dirt can build up, as a share of the '
                    'object\'s size')
    maps_occlusion_reach: FloatProperty(
        name='Occlusion Reach', default=25.0, min=1.0, max=100.0, subtype='PERCENTAGE', precision=0,
        description='How far the analysis looks for enclosing surfaces (pockets, insets, the ground), as a '
                    'share of the object\'s size')
    maps_other_objects: BoolProperty(
        name='Include Other Objects', default=True,
        description='Other objects nearby (the floor, parts touching each other) also make corners and '
                    'shade the object. Off: each object is analyzed on its own')
    analysis_view: EnumProperty(
        name='View Maps',
        items=V.MODES,
        default='OFF', update=_analysis_view_changed,
        description='Show the shape analysis on the objects instead of their materials (Material Preview), '
                    'to check what it found. Objects without maps show dark purple')
    maps_save_dir: StringProperty(
        name='Folder', subtype='DIR_PATH', default='//BPM_Mesh_Maps/',
        description='Where "Save as Images" writes the mesh maps ("//" means next to your .blend file)')
    auto_mesh_maps: BoolProperty(
        name='Analyze Shape First', default=True,
        description='Auto Texture: analyze the shape of objects without (up-to-date) mesh maps before '
                    'baking, so edge wear and grime follow the edges and corners exactly')

    # --- decals
    decal_image: PointerProperty(
        type=bpy.types.Image, name='Decal Image',
        description='Image for the next decal. Its normal, roughness, metallic and height maps are found '
                    'automatically when they are saved next to it with the same name (Logo_Normal.png...)')

    # --- results
    last_folder: StringProperty(default='')
    last_report: StringProperty(default='')
    last_level: StringProperty(default='INFO')
    last_warnings: StringProperty(default='')


CLASSES = (BPM_SlotBackup, BPM_ViewSlot, BPM_Settings)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.bpm = PointerProperty(type=BPM_Settings)
    bpy.types.Object.bpm_backup = CollectionProperty(type=BPM_SlotBackup)
    bpy.types.Object.bpm_view_slots = CollectionProperty(type=BPM_ViewSlot)


def unregister():
    del bpy.types.Object.bpm_view_slots
    del bpy.types.Object.bpm_backup
    del bpy.types.Scene.bpm
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
